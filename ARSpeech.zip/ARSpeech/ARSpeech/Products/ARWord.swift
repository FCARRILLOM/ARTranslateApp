//
//  ARWord.swift
//  ARSpeech
//
//  Created by Fernando Carrillo on 8/21/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import Foundation
import SceneKit

class ARWord: SCNNode {
    // variables
    var word: String!
    let textGeometry = SCNText(string: "", extrusionDepth: 1.0)
    
    // initializers
    override init() {
        super.init()
        word = "NA"
    }
    
    init(newWord: String) {
        super.init()
        word = newWord
        createWordGeometry()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // creates the 3D word
    func createWordGeometry() {
        // assigns text color
        textGeometry.firstMaterial?.diffuse.contents = UIColor.black
        
        textGeometry.string = word
        
        self.geometry = textGeometry
        
        let scale = 0.009
        self.scale = SCNVector3(scale, scale, scale)
    }
    
}
