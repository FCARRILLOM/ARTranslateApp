//
//  LanguagePickerView.swift
//  ARSpeech
//
//  Created by Fernando Carrillo on 8/22/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import UIKit

class LanguagePickerView: UIPickerView {
    // data
    let languageCodes = ["default", "zh-Hans", "de", "en", "es", "fr", "ja", "ko", "it", "ru", "sv"]
    let languages = ["Choose language", "Chinese/Mandarin", "Deutsch", "English", "Español", "Français", "Japanese", "Korean", "Italiano", "Russian", "Swedish"]
    // variables
    var currentLanguage = "Choose language"
    var currentLanguageCode = "default"
    var currentLanguageIndex = 0
    
    // selected row function
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        currentLanguage = languages[row]
        currentLanguageIndex = row
    }
    
    // returns the language code that is chosen at the time
    func getCurrentLanguageCode() -> String {
        return languageCodes[currentLanguageIndex]
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
}

// extension
extension LanguagePickerView: UIPickerViewDataSource, UIPickerViewDelegate {
    // returns the number of 'columns' to display. only one for languages
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // returns the # of rows in each component..
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return languages.count
    }
    
    // titles for the picker view rows
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return languages[row]
    }
}
