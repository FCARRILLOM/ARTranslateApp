//
//  ViewController.swift
//  ARSpeech
//
//  Created by Fernando Carrillo on 8/21/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

// in this view the user will be able to see the tranlsated text appear over his screen.
// to make this work on your device you need to enter your google api key in line 199
// tutorials followed:
// recording audio - https://www.youtube.com/watch?v=CrLbuzM9IDs&index=31&list=WL
// speech recognition - https://www.youtube.com/watch?v=2gs5QTRC8Yk&list=WL&t=87s&index=31
// cocoa pod for Google Translate api - https://github.com/prine/ROGoogleTranslate

import UIKit
import SceneKit
import ARKit
import Speech
import AVFoundation
import ROGoogleTranslate

class ARViewController: UIViewController, ARSCNViewDelegate, AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    // variables sent from previous view controller
    var sourceLanguageCode = ""
    var targetLanguageCode = ""
    
        // speech to text variables
    var spritzTimer = Timer()
    var text = "NA"
    var translatedText = "NA"
    @IBOutlet weak var textLabel: UILabel!
    
        // audio recording variables
    var recordingSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    var audioURL: URL!
    @IBOutlet weak var recordAudioOutlet: UIButton!
    
        // speech recognition variables
    var audioPlayer: AVAudioPlayer!
    
        // view variables
    @IBOutlet var sceneView: ARSCNView!
    @IBOutlet weak var activitySpinner: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(sourceLanguageCode, targetLanguageCode)
        
        // audio recording
            // setting up session
        recordingSession = AVAudioSession.sharedInstance()
        
        AVAudioSession.sharedInstance().requestRecordPermission { (hasPermission) in
            if(hasPermission) {
                print("Permission granted")
            } else {
                print("No permission")
            }
        }
        
        // activity spinner starts hidden
        activitySpinner.isHidden = true
        
        // Set the view's delegate
        sceneView.delegate = self
        
        // Show statistics such as fps and timing information
        sceneView.showsStatistics = false
    }
    
    // MARK: - Audio Recording
    
    // when user presses button, audio is recorded
    @IBAction func recordAudio(_ sender: Any) {
        // check for active recording
        if(audioRecorder == nil) {
            activitySpinner.isHidden = true
            activitySpinner.stopAnimating()
            let filename = getDirectory().appendingPathComponent("testAudio.m4a")
            let settings = [AVFormatIDKey: Int(kAudioFormatMPEG4AAC), AVSampleRateKey: 12000, AVNumberOfChannelsKey: 1, AVEncoderAudioQualityKey: AVAudioQuality.medium.rawValue]
            
            // start audio recording
            do {
                print("Recording")
                audioRecorder = try AVAudioRecorder(url: filename, settings: settings)
                audioRecorder.delegate = self
                audioRecorder.record()
                
                recordAudioOutlet.setTitle("Stop recording", for: .normal)
            } catch {
                displayAlert(title: "Error", message: "Recording audio failed")
            }
            
        } else {
            // stops audio recording
            recordAudioOutlet.setTitle("Start recording", for: .normal)
            audioRecorder.stop()
            audioRecorder = nil
            
            // starts speech recognition
            activitySpinner.isHidden = false
            activitySpinner.startAnimating()
            requestSpeechAuth()
        }
    }
    
    // function that gets path in directory to where audio recording is stored
    func getDirectory() -> URL {
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = path[0]
        return documentDirectory
    }
    
    // plays the audio to the user
    func playAudio() {
        let path = self.getDirectory().appendingPathComponent("testAudio.m4a")
        // plays the audio file
        do {
            let sound = try AVAudioPlayer(contentsOf: path)
            audioPlayer = sound
            audioPlayer.delegate = self
            sound.play()
            
        } catch {
            print("Error playing audio")
        }
    }
    
    
    // MARK: - Speech Recognition
    
    // function that requests authorization for microphone
    func requestSpeechAuth() {
        print("Requesting speech recognition...")
        SFSpeechRecognizer.requestAuthorization {_ in
            switch SFSpeechRecognizer.authorizationStatus() {
            case .authorized:
                print("Authorized")
                let path = self.getDirectory().appendingPathComponent("testAudio.m4a")
                
                // speech recognition
                let recognizer = SFSpeechRecognizer(locale: Locale(identifier: self.sourceLanguageCode))
                let request = SFSpeechURLRecognitionRequest(url: path)
                
                recognizer?.recognitionTask(with: request) {(result, error) in
                    if let error = error {
                        print("Error in speech recognition: \(error)")
                        self.text = "Error"
                    } else {
                        // plays the audio file
                        self.playAudio()
                        self.text = result?.bestTranscription.formattedString as Any as! String
                        //print(self.text)
                        if(result?.isFinal)! {
                            self.translate()
                        }
                    }
                }
                
                break
                
            case .denied:
                print("Denied")
                break
                
            case .notDetermined:
                print("Not determined")
                break
                
            case .restricted:
                print("Restricted")
                break
            }
        }
    }
    
    // audio is finished playing
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        player.stop()
        activitySpinner.stopAnimating()
        activitySpinner.isHidden = true
    }
    
    // MARK: - Google Translate API
    func translate() {
        print("Source: \(text)")
        if(text != "Error" || text != "NA") {
            
            // if languages are the same, no translation is made
            if(sourceLanguageCode != targetLanguageCode) {
                let params = ROGoogleTranslateParams(source: sourceLanguageCode,
                                                     target: targetLanguageCode,
                                                     text: text)
                
                // Enter your key here
                let translator = ROGoogleTranslate(key: "Enter your key here")
                
                translator.translate(params: params) { (result) in
                    print("Translation: \(result)")
                    self.translatedText = result
                    self.displayText(sentence: result)
                }
            } else {
                print("No translation")
                displayText(sentence: text)
            }
        } else {
            print("Could not translate")
        }
    }
    
    
    // MARK: - AR Spritz
    
    // displays the text following the Spritz model in which words are rapidly placed in the center of the users vision
    func displayText(sentence: String) {
        print("Text to be displayed: \(sentence)")
        if(sentence != "Error") {
            // AR words
//            var wordNode: SCNNode!
//
//            // positions
//            let x: Float = 0.0
//            let y: Float = 0.0
//            let z: Float = -0.5
//
//            let words = sentence.components(separatedBy: " ")
//            for word in words {
//                wordNode = ARWord(newWord: word)
//                sceneView.scene.rootNode.addChildNode(wordNode)
//                wordNode.position = SCNVector3(x: x, y: y, z: z)
//                usleep(600000)
//                wordNode.removeFromParentNode()
//            }
            
            // 2d words
            let words = sentence.components(separatedBy: " ")
            for word in words {
                DispatchQueue.main.async {
                    self.textLabel.text = word
                }
                usleep(300000)
            }
        }
    }
    
    // repeats the whole sentences ---- not working
    @IBAction func repeatButton(_ sender: Any) {
        if(translatedText != "NA") {
            displayText(sentence: translatedText)
            playAudio()
        }
    }
    
    
    // MARK: - Extra
    
    // function that displays alerts
    func displayAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = AROrientationTrackingConfiguration()

        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    // MARK: - ARSCNViewDelegate
    
/*
    // Override to create and configure nodes for anchors added to the view's session.
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let node = SCNNode()
     
        return node
    }
*/
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}
