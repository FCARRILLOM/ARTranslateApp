//
//  MenuViewController.swift
//  ARSpeech
//
//  Created by Fernando Carrillo on 8/21/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

// In this view the user will be able to choose the languages that are to be translated.

import UIKit

class MenuViewController: UIViewController {
    // variables, source language is input language and target is output language
    var sourceLanguageCode = ""
    var targetLanguageCode = ""
    
    // ui pickers
    var sourceModelPicker: LanguagePickerView!
    var targetModelPicker: LanguagePickerView!
    @IBOutlet weak var sourceLanguage: UIPickerView!
    @IBOutlet weak var targetLanguage: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // assigns picker view data
        sourceModelPicker = LanguagePickerView()
        targetModelPicker = LanguagePickerView()
        sourceLanguage.delegate = sourceModelPicker
        targetLanguage.delegate = targetModelPicker
        sourceLanguage.dataSource = sourceModelPicker
        targetLanguage.dataSource = targetModelPicker
        
    }

    
    // MARK: - Extra
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // the user is finished choosing the languages
    @IBAction func readyButton(_ sender: Any) {
        sourceLanguageCode = sourceModelPicker.getCurrentLanguageCode()
        targetLanguageCode = targetModelPicker.getCurrentLanguageCode()
        // checks that languages are chosen
        if(sourceLanguageCode != "default" && targetLanguageCode != "default") {
            performSegue(withIdentifier: "toARView", sender: self)
        }
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "toARView") {
            let ARVC = segue.destination as! ARViewController
            ARVC.sourceLanguageCode = sourceLanguageCode
            ARVC.targetLanguageCode = targetLanguageCode
        }
    }
    

}
